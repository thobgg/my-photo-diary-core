# MPD Android Icon — Einbau in Android Studio (GUI)

**Ziel:** Einbau komplett in der Android-Studio-Oberfläche. Kein Terminal.

Das Motiv ist genau auf die Größe anderer App-Icons (DuckDuckGo, Bitwarden)
abgestimmt. Adaptive Icon mit zwei Layern — wie Android es heute erwartet.

---

## Variante 1: Image Asset Studio (EMPFOHLEN)

Das eingebaute Tool von Android Studio. Es erzeugt alle Dateien automatisch —
du gibst nur die Quell-SVGs und die Hintergrundfarbe rein.

### Schritt 1: Alte Icons löschen

Im **Project-Panel links** oben auf **Android** umschalten (falls nicht schon).
Navigiere zu:

```
app → res → mipmap
```

Du siehst dort Einträge wie `ic_launcher`, `ic_launcher_round` mit mehreren
Varianten (anydpi-v26, mdpi, hdpi, xhdpi, xxhdpi, xxxhdpi).

**Rechtsklick auf `ic_launcher` → Delete** → bei der Nachfrage **OK** bzw.
**Delete Anyway**.

Gleiches für `ic_launcher_round`.

### Schritt 2: Quell-SVGs bereit legen

Aus diesem Paket zwei Dateien irgendwohin entpacken (z.B. `~/Downloads/mpd-icons/`):

- `foreground_large.svg` — Tagebuch + Kamera + Stift
- `monochrome_large.svg` — einfarbig für Themed Icons

### Schritt 3: Image Asset Studio öffnen

**Rechtsklick auf `res`** (oder `app/src/main/res`) im Project-Panel:

```
New → Image Asset
```

Das Fenster **Configure Image Asset** öffnet sich.

### Schritt 4: Foreground Layer

Oben:
- **Icon Type:** `Launcher Icons (Adaptive and Legacy)` (Default)
- **Name:** `ic_launcher` (Default — lassen)

Tab **Foreground Layer**:
- **Asset Type:** `Image` auswählen
- **Path:** auf das Ordner-Symbol klicken → `foreground_large.svg` wählen
- **Trim:** `No` (**wichtig!** — sonst verrutscht das Motiv)
- **Resize:** Slider auf **100%** lassen

Rechts im Preview-Panel siehst du das Icon unter verschiedenen Masken —
dort sollte das Motiv überall gut sichtbar sein.

### Schritt 5: Background Layer

Tab **Background Layer**:
- **Asset Type:** `Color`
- **Color:** aufs Farbfeld klicken, Hex-Wert eingeben: **`F4EFE6`**

### Schritt 6: Monochrome Layer (für Themed Icons)

In neueren Android-Studio-Versionen ist dieser Tab direkt sichtbar, in
älteren unter **Options**.

- **Source Asset:** `monochrome_large.svg`
- **Trim:** `No`

Falls dein Android Studio kein Monochrome-Feld anbietet: einfach überspringen.
Themed Icons (Android 13+) funktionieren dann nicht optimal, alles andere aber schon.

### Schritt 7: Legacy Tab

- **Generate Legacy Icon:** `Yes`
- **Shape:** `Circle` oder `Square` — egal, betrifft nur sehr alte Geräte
- **Generate Round Icon:** `Yes`

### Schritt 8: Fertigstellen

**Next** → Preview der generierten Dateien erscheint → **Finish**.

Android Studio erzeugt automatisch alle nötigen Dateien in
`app/src/main/res/mipmap-*/` und `values/`.

### Schritt 9: Bauen

- **Build → Clean Project** (warten)
- **Build → Rebuild Project** (warten)
- **Build → Build Bundle(s) / APK(s) → Build APK(s)**

Unten rechts die Notification "APK(s) generated successfully" → auf
**locate** klicken → dort liegt deine neue APK.

### Schritt 10: Auf dem Tab austauschen

**Wichtig:** Alte MPD-App auf dem Gerät **komplett deinstallieren**
(nicht updaten — der Launcher cached das Icon sonst).

Neue APK aufs Gerät und installieren.

Falls Icon trotzdem noch das alte sein sollte:
- Homescreen lang gedrückt halten → Einstellungen → Home neu laden
- Oder: Tab einmal neu starten

---

## Variante 2: Falls Image Asset Studio Probleme macht

Manche Android-Studio-Versionen haben Schwierigkeiten mit SVG-Import.
Dann: Dateien direkt einfügen.

### Schritt A: Alte Icons löschen (wie Variante 1 Schritt 1)

### Schritt B: Dateimanager öffnen

Im Project-Panel **Rechtsklick auf `app/src/main/res`** →
**Open In → Files** (oder "Show in Files" / "Reveal in Explorer" je nach System).

### Schritt C: Dateien reinkopieren

Das ZIP entpacken. Den Inhalt von `android_package/app/src/main/res/`
**per Drag & Drop** in den `res`-Ordner deines Projekts ziehen.

Bei Konflikten: **"Zusammenführen"** bzw. **"Ersetzen"** wählen.

### Schritt D: Zurück in Android Studio

Android Studio merkt die neuen Dateien normalerweise automatisch.
Falls nicht:

- **File → Sync Project with Gradle Files**

Im Notfall, wenn Android Studio verwirrt wirkt:
- **File → Invalidate Caches / Restart → Invalidate and Restart**

### Schritt E: AndroidManifest prüfen

`app/src/main/AndroidManifest.xml` öffnen.

Im `<application ...>`-Tag müssen diese Attribute stehen:

```xml
android:icon="@mipmap/ic_launcher"
android:roundIcon="@mipmap/ic_launcher_round"
```

Sind sie da? Passt. Sind sie anders? Ändern.

### Schritt F: Bauen wie Variante 1 Schritt 9

---

## Paket-Inhalt

```
android_package/
├── README.md                      ← dieses Dokument
├── foreground_large.svg           ← für Image Asset Studio Schritt 4
├── monochrome_large.svg           ← für Image Asset Studio Schritt 6
├── play_store/
│   └── ic_launcher_playstore.png  ← 512x512, später für Play Store
└── app/src/main/res/              ← für Variante 2 (direkt einfügen)
    ├── mipmap-anydpi-v26/
    ├── mipmap-mdpi/    bis  mipmap-xxxhdpi/
    └── values/ic_launcher_colors.xml
```

---

## Häufige Fehler

### "Resource ic_launcher_background already defined"
In `values/colors.xml` gibt es noch einen alten Eintrag. Datei öffnen
(Android Studio, im Project-Panel unter `res/values/`), Zeile mit
`ic_launcher_background` **löschen**.

### "Resource mipmap/ic_launcher_foreground not found"
Eine Dichte fehlt. Image Asset Studio noch mal durchlaufen, oder im
Dateimanager prüfen ob in allen fünf `mipmap-*`-Ordnern die Datei
`ic_launcher_foreground.png` liegt.

### Icon auf dem Tab ändert sich nicht
1. App wirklich **deinstalliert** und neu installiert?
2. Einstellungen → Apps → "One UI Home" → Speicher → Cache leeren
3. Tab neu starten

### Samsung zeigt Icon mit dünnem Rahmen drumherum
Einstellungen → Anzeige → Icon-Rahmen → **Nur Symbole** wählen.
Oder: Samsung tut das immer bei Apps außerhalb des Play Stores — kein Bug.

---

## Hintergrund-Info

- **Scale 0.75** im Foreground-SVG — das Motiv füllt ~84% der Icon-Fläche.
  Damit ist es gleich groß wie DuckDuckGo, Bitwarden & Co.
- Bei extremen Circle-Launchern (Pixel) wird die Stiftkappe oben-rechts
  minimal angeknabbert. Auf Samsung One UI (Squircle) ist alles sichtbar.
- Definitions-Quelle: MPD CI v1.1 §7.2
